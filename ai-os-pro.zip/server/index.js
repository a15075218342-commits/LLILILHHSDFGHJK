import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const workflow = {
  steps: [
    { type: "llm", prompt: "你是一个爆款内容专家" },
    { type: "llm", prompt: "把内容改成短视频脚本" }
  ]
};

app.post("/run", async (req, res) => {
  let data = req.body.input;

  for (let step of workflow.steps) {
    const response = await client.chat.completions.create({
      model: "gpt-4.1-mini",
      messages: [
        { role: "system", content: step.prompt },
        { role: "user", content: data }
      ]
    });
    data = response.choices[0].message.content;
  }

  res.json({ result: data });
});

app.listen(3001, () => console.log("Server running on 3001"));
